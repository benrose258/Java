// Ben Rose
// I pledge my honor that I have abided by the Stevens Honor System.
// Due: 9/15/2020

/*
"Remark con chunks in HW1 (Post by instructor regarding the assignment):

I would like to clarify something regarding chunks. 

Suppose I have a file of size 20 and my chunk size is 4. Then I will have a total of 5 chunks. 

A rearrangement pattern establishes  how those 5 chunks will be rearranged in the input file to produce the output file. For example, the rearrangement pattern a b d c e, swaps chunks three and four leaving the others unchanged.

All this is irrelevant of the actual content of the file that is being rearranged. For example, if the file is

12345678901234567890

Then the output, using the above mentioned rearrangement, would be:

12345678345690127890

since chunks three (9012) and four (3456) have been swapped.
 */

package homework1;

import java.io.*;
import java.util.*;

public class TextSwap {

    private static String readFile(String filename) throws Exception {
        String line;
        StringBuilder buffer = new StringBuilder();
//        System.out.println("Working Directory = " + System.getProperty("user.dir")); // Used for debugging file access
        File file = new File(System.getProperty("user.dir") + filename);
        BufferedReader br = new BufferedReader(new FileReader(file));
        while ((line = br.readLine()) != null) {
            buffer.append(line);
        }
        br.close();
//        System.out.println("Buffer = " + buffer); // Debugging for detecting location of the "multiples" error statement
        return buffer.toString();
    }

    private static Interval[] getIntervals(int numChunks, int chunkSize) {
        // TODO: Implement me!
    	Interval[] myIntervals = new Interval[numChunks]; // The final list of intervals
    	for (int i = 0; i < numChunks; i++) { // For each interval in the input
    		int i_times_chunkSize = i * chunkSize; // Creating i * chunkSize to avoid duplicate calculations
    		// One of the intervals in the input, from i_times_chunkSize to i_times_chunkSize-1
    		// For example, in an input with chunkSize 4 and file size 20, the intervals would be:
    		// 0 to 3, 4 to 7, 8 to 11, 12 to 15, and 16 to 19. This totals 20, from 0-19 inclusive.
    		Interval oneInterval = new Interval(i_times_chunkSize, (i_times_chunkSize + chunkSize) - 1);
    		myIntervals[i] = oneInterval; // (myIntervals at the index i) = (the created interval oneInterval)
    	}
    	return myIntervals;
    }

    private static List<Character> getLabels(int numChunks) {
        Scanner scanner = new Scanner(System.in);
        List<Character> labels = new ArrayList<Character>();
        int endChar = numChunks == 0 ? 'a' : 'a' + numChunks - 1;
        System.out.printf("Input %d character(s) (\'%c\' - \'%c\') for the pattern.\n", numChunks, 'a', endChar);
        for (int i = 0; i < numChunks; i++) {
            labels.add(scanner.next().charAt(0));
        }
        scanner.close();
        System.out.println(labels);
        return labels;
    }

    private static char[] runSwapper(String content, int chunkSize, int numChunks) {
        List<Character> labels = getLabels(numChunks);
        Interval[] intervals = getIntervals(numChunks, chunkSize);
        // TODO: Order the intervals properly, then run the Swapper instances.
        char[] originalMessage = content.toCharArray();
        char[] swappedMessage = new char[content.length()]; // Creating the final char array of equal length to the content string
        int largestChar = numChunks == 0 ? 'a' : 'a' + numChunks - 1; // Adding largestChar to see if an error should be thrown because the string is out of the char bounds
        for (int i = 0; i < numChunks; i++) {
        	char labelsAtI = labels.get(i); // Initializing a char variable to reduce computations
        	if (labelsAtI > largestChar) { // If the label for the chunk is greater than the potentially allowed labels
        		// Print an error message indicating that the scanned label is invalid, as it would be out of range
        		System.out.printf("Error: the character \"" + labelsAtI + "\" at index " + i + " is larger than the greatest allowed character, \"%c\".\nPlease try again.", largestChar);
        		System.exit(1); // Exit the program indicating that the execution failed.
        	}
        	int whichInterval = labelsAtI - 97; // whichInterval in the list of intervals we should use in our swapped chunks. 97 is the numerical value of the char 'a'.
        	Interval selectedInterval = intervals[whichInterval]; // Creating a variable to store the relevant interval for the used chunk in the swap
//        	boolean awaitingWakeup = true;
//        	Swapper swappingThread = new Swapper(selectedInterval, content, swappedMessage, i, awaitingWakeup);
//        	swappingThread.run();
//        	while (awaitingWakeup) {	
//        	}
        	for (int j = selectedInterval.getX(); j <= selectedInterval.getY(); j++) { // For each value from the lower bound of the selected interval (=x) up to and including the upper bound of the selected interval (=y)
        		swappedMessage[(i * chunkSize) + (j - selectedInterval.getX())] = originalMessage[j]; // Run this line that has its function documented below.
        		// swappedMessage at (i * the size of a chunk) + 
        		//					(j, which starts at the beginning of the interval and incremented by 1, - the beginning of the interval)
        		//					= the original message at the "j"th position.
        		// For example, in an input with chunkSize 4, file size 20, and numChunks = 5, the intervals would be:
        		// 0 to 3, 4 to 7, 8 to 11, 12 to 15, and 16 to 19. This totals 20, from 0-19 inclusive.
        		// i would start at 0, and let's assume the selected interval is 12 to 15.
        		// (i * chunkSize) = 0 * 4 = 0, (j - selectedInterval.getX()) = 12 - 12 = 0.
        		// So, swappedMessage at 0 + 0 = swappedMessage[0], which now equals originalMessage[12].
        		// increment j for next iteration. j now equals 13.
        		// (i * chunkSize) = 0 * 4 = 0, (j - selectedInterval.getX()) = 13 - 12 = 1.
        		// So, swappedMessage at 0 + 1 = swappedMessage[1], which now equals originalMessage[13].
        		// Let's go to a different value of i.
        		// Now, in this new case, the intervals and the chunk and file size are the same, but
        		// now i = 2. The selected interval is 16 to 19.
        		// (i * chunkSize) = 2 * 4 = 8, (j - selectedInterval.getX()) = 16 - 16 = 0
        		// So, swappedMessage at 8 + 0 = swappedMessage[8], which now equals originalMessage[16].
        		// increment j for next iteration. j now equals 17.
        		// (i * chunkSize) = 2 * 4 = 8, (j - selectedInterval.getX()) = 17 - 16 = 1
        		// So, swappedMessage at 8 + 1 = swappedMessage[9], which now equals originalMessage[17].
        		// increment j for next iteration. j now equals 18.
        		// (i * chunkSize) = 2 * 4 = 8, (j - selectedInterval.getX()) = 18 - 16 = 2
        		// So, swappedMessage at 8 + 2 = swappedMessage[10], which now equals originalMessage[18].
        		// increment j for next iteration. j now equals 18.
        		// (i * chunkSize) = 2 * 4 = 8, (j - selectedInterval.getX()) = 19 - 16 = 3
        		// So, swappedMessage at 8 + 3 = swappedMessage[11], which now equals originalMessage[19].
        		// Let's go to the edge value of i.
        		// Now, in this new case, the intervals and the chunk and file size are the same, but
        		// now i = 4. The selected interval is 4 to 7.
        		// (i * chunkSize) = 4 * 4 = 16, (j - selectedInterval.getX()) = 4 - 4 = 0
        		// So, swappedMessage at 16 + 0 = swappedMessage[16], which now equals originalMessage[4].
        		// increment j for next iteration. j now equals 5.
        		// (i * chunkSize) = 4 * 4 = 16, (j - selectedInterval.getX()) = 5 - 4 = 1
        		// So, swappedMessage at 16 + 1 = swappedMessage[17], which now equals originalMessage[5].
        		// increment j for next iteration. j now equals 6.
        		// (i * chunkSize) = 4 * 4 = 16, (j - selectedInterval.getX()) = 6 - 4 = 2
        		// So, swappedMessage at 16 + 2 = swappedMessage[18], which now equals originalMessage[6].
        		// increment j for next iteration. j now equals 7.
        		// (i * chunkSize) = 4 * 4 = 16, (j - selectedInterval.getX()) = 7 - 4 = 3
        		// So, swappedMessage at 16 + 3 = swappedMessage[19], which now equals originalMessage[7].
        		// After that value of i, the for loop is complete and the swappedMessage char array will be returned.
        		
        	}
        }
        return swappedMessage;
    }

    private static void writeToFile(String contents, int chunkSize, int numChunks) throws Exception {
        char[] buff = runSwapper(contents, chunkSize, contents.length() / chunkSize);
        System.out.println("Original string (for debugging and visualization): \"" + contents + "\"");
//        System.out.println("Rearranged string (for debugging and visualization): \"" + buff.toString() + "\""); // ummm, this one didn't work, interesting results, though.
        PrintWriter writer = new PrintWriter("output.txt", "UTF-8");
        writer.print(buff);
        writer.close();
    }

    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java TextSwap <chunk size> <filename>\n\nNote: filename must be in current working directory with a preceding\n\"\\\" in Windows and a proceeding \"/\" in macOS.");
            return;
        }
        String contents = "";
        int chunkSize = Integer.parseInt(args[0]);
        if (chunkSize < 1) { // If argv[0] is not positive
        	System.out.println("Error: Chunk size must be positive.");
        	return;
        }
        if (chunkSize > 26) { // If argv[0] is greater than 26
        	System.out.println("Error: Chunk size is too large.");
        	return;
        }
//        int charAsA = 'a'; // This and the next line are used for debugging, locating the integer value of the character 'a'
//        System.out.println("The number corresponding to \'a\' as a char is \"" + charAsA + "\".");
//        System.out.println(chunkSize); // debugging
        try {
            contents = readFile(args[1]);
            if (contents.length() % chunkSize != 0) { // If the chunk size is not a multiple of the string found in the file
            	System.out.println("Error: The size of the file's string must be a multiple of the chunk size.");
            	return;
            }
            System.out.println("File contents (for debugging only): \"" + contents + "\""); // debugging only, del later
            writeToFile(contents, chunkSize, contents.length() / chunkSize);
        } catch (Exception e) {
            System.out.println("Error with IO. Did you check the updated Usage message with notes on how to specify the file?");
            return;
        }
    }
}