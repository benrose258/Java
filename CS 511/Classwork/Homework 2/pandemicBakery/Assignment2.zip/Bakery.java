package homework2;

// import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
// import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class Bakery implements Runnable {
    private static final int TOTAL_CUSTOMERS = 200;
    private static final int ALLOWED_CUSTOMERS = 50;
    private static final int FULL_BREAD = 20;
    private Map<BreadType, Integer> availableBread;
    private ExecutorService executor;
    private float sales = 0;
    
    public Semaphore shelfAccess = new Semaphore(1); // Create a new semaphore to control access to the bread shelf
    public Semaphore cashiers = new Semaphore(4); // Allow four cashiers to be available for checkout

    // TODO

    /**
     * Remove a loaf from the available breads and restock if necessary
     */
    public void takeBread(BreadType bread) {
//    	System.out.println("Bread that has been passed to takeBread="+ bread);
//    	System.out.println("Is available bread == null in takeBread? answer= \"" + (availableBread == null) + "\"");
//    	System.out.println("Available bread of type" + bread + " equals " + availableBread.get(bread));
//    	System.out.println("I am Hash code \"" + hashCode() + "\"");
        
//    	System.out.println("Uncomment breadLeft stuff after invasive debugging.");
    	int breadLeft = availableBread.get(bread);
        if (breadLeft > 0) {
//        		shelfAccess.acquire(); // Restrict access to the shelf while grabbing bread
//        		System.out.println("Hash code \"" + hashCode() + "\" is accessing the shelf.");// in the \"if\" statement.");
    		availableBread.put(bread, breadLeft - 1);
        } else {
            System.out.println("No " + bread + " bread left! Restocking...");
            // restock by preventing access to the bread stand for some time
            try {
//            	shelfAccess.acquire(); // Restrict access to the shelf during restocking
//            	System.out.println("Hash code \"" + hashCode() + "\" is accessing the shelf.");
                Thread.sleep(1000); // Sleep for 1000 milliseconds == 1 second
            } catch (InterruptedException ie) {
                ie.printStackTrace();
            }
            availableBread.put(bread, FULL_BREAD - 1);
        }
//        System.out.println("Hash code \"" + hashCode() + "\" is stopping accessing the shelf.");
//        shelfAccess.release(); // Now that access to the shelf is no longer required, allow access to be taken again.
        addSales(bread.getPrice()); // Add the value of the purchased bread to the total sales
//      System.out.println("Hash code \"" + hashCode() + "\" grabbed a loaf of " + bread + " and has stopped accessing the shelf.");// + " The new sales total is " + sales);
    }
    
    

    /**
     * Add to the total sales
     */
    public void addSales(float value) {
        sales += value;
    }
    
//    public int checkout(float cartValue) { // Let a customer check out for the value of items in their cart and return the time it took
    public void checkout(float cartValue) { // Check out with the cat value
//    	System.out.println("Cart value in the Bakery checkout function is " + cartValue);
//    	long start = System.nanoTime(); // Record the starting time
//    	try {
//    		cashiers.acquire(); // Try to get a cashier and wait until one is free
//    		System.out.println("Hash code \"" + hashCode() + "\" is checking out.");
////    		System.out.println("Cashiers available: " + cashiers.availablePermits()); // Debugging, used in confirming acquire/release function, which is working.
//    	} catch (InterruptedException ie) {
//    		ie.printStackTrace();
//    	}
    	
    	addSales(cartValue); // Add the amount of money obtained from the customer checking out to the total sales
    	
//    	cashiers.release(); // Cashier is freed up
//    	System.out.println("Hash code \"" + hashCode() + "\" is finished checking out. The new sales total is " + sales);
//    	long end = System.nanoTime(); // Record the ending time
//    	System.out.println("Start time in nanosecs: " + start + ", End time in nanosecs: " + end + ", Difference in nanosecs: " + (end - start));
//    	return (int) (end - start);
    }

    /**
     * Run all customers in a fixed thread pool
     */
    public void run() {
        
        availableBread = new ConcurrentHashMap<BreadType, Integer>();
        availableBread.put(BreadType.RYE, FULL_BREAD);
        availableBread.put(BreadType.SOURDOUGH, FULL_BREAD);
        availableBread.put(BreadType.WONDER, FULL_BREAD);
        
//        System.out.println("Main thread's hash code is = " + hashCode()); // Debugging
        
//        System.out.println("Is available bread == null before the initial breadleft statement? answer= \"" + (bakery.availableBread == null) + "\"");// + "\" Is it empty? answer=" + bakery.availableBread.isEmpty());
        
//        System.out.println("Initial breads: Rye bread left=" + availableBread.get(BreadType.RYE) + ", Sourdough bread left=" + availableBread.get(BreadType.SOURDOUGH) + ", Wonder bread left=" + availableBread.get(BreadType.WONDER));
        
//        int currentTotalCustomers = TOTAL_CUSTOMERS; // Initialize how many customers are currently allowed today
        

        
//        ArrayList<Thread> customerList = new ArrayList<Thread>(TOTAL_CUSTOMERS); // Initialize an array of customer threads for the day
//        System.out.println("Is available bread == null before the while loop? answer= \"" + (availableBread == null) + "\""); //Is it empty? answer=" + bakery.availableBread.isEmpty());
//        while (customerList.size() < 200) { // When we can still have customers this day (instance of bakery)
//        	Thread thread = new Thread(new Customer(bakery));
//        	customerList.add(thread);
//        }
        
        executor = Executors.newFixedThreadPool(ALLOWED_CUSTOMERS); // Create the executor service with ALLOWED_CUSTOMERS allowed threads running concurrently
        for (int i = 0; i < TOTAL_CUSTOMERS; i++) { // For each of the total customers allowed that day
        	executor.execute(new Customer(this)); // Execute one customer thread
        }
        
//        System.out.println("The total money made supposedly after thread joining is \"" + sales + "\". For debugging.");
        executor.shutdown(); // Shut down the executor service
//        try { // Wait for all threads to terminate to run remaining code
//			executor.awaitTermination(60, TimeUnit.SECONDS);
//		} catch (InterruptedException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
        try {
			if (executor.awaitTermination(60, TimeUnit.SECONDS)) { // Wait for all threads to terminate
				// Print total sales for the day and the Bakery's closing message.
				System.out.println("\nThe total money made is \"$" + sales + "\".\nThe bakery is now closed for the day. Thanks for visiting!");
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
//        LinkedBlockingQueue<Customer> customerQueue = new LinkedBlockingQueue<Customer>();
//        for (int i = 0; i < TOTAL_CUSTOMERS; i++) {
//        	customerQueue.add(new Customer(bakery));
//        }
        
        
        
//        int currentlyAllowedCustomers = ALLOWED_CUSTOMERS;
        
//        System.out.println("Is available bread == null before the for loop? answer= \"" + (bakery.availableBread == null) + "\"");
//        System.out.println("Still initial but later on breads: Rye bread left=" + availableBread.get(BreadType.RYE) + ", Sourdough bread left=" + availableBread.get(BreadType.SOURDOUGH) + ", Wonder bread left=" + availableBread.get(BreadType.WONDER));
//        for (int i = 0; i < customerList.size(); i++) { // For every customer thread in the customer list
////        	System.out.println("Is available bread == null in for loop? answer= \"" + (bakery.availableBread == null) + "\"");
////        	System.out.println("Still initial but in thread creation breads: Rye bread left=" + availableBread.get(BreadType.RYE) + ", Sourdough bread left=" + availableBread.get(BreadType.SOURDOUGH) + ", Wonder bread left=" + availableBread.get(BreadType.WONDER));
//        	customerList.get(i).start(); // Start the customer thread at the index i
//        }
        
//        for (Thread thread : customerList) { // Try joining the customer threads
//        	try {
//				thread.join();
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//        }
        
//        System.out.println("The total money made supposedly after thread joining is \"" + sales + "\". For debugging.");
        
//        System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfterwards breads: Rye bread left=" + availableBread.get(BreadType.RYE) + ", Sourdough bread left=" + availableBread.get(BreadType.SOURDOUGH) + ", Wonder bread left=" + availableBread.get(BreadType.WONDER));
    }
}