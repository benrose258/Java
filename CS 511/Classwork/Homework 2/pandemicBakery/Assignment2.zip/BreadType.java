package homework2;

public enum BreadType {
    RYE (3.99f),
    SOURDOUGH (4.99f),
    WONDER (5.99f);

    private float price;

    BreadType(float price) {
        this.price = price;
    }

    public float getPrice() {
        return price;
    }
    
//    public String toString() { // toString method to visualize the bread
//    	if (price == 3.99) { // If we've picked up a loaf of Rye bread
//    		return "Rye";
//    	} else if (price == 4.99) { // If we've picked up a loaf of Sourdough bread
//    		return "Sourdough";
//    	} else { // If we've picked up a loaf of Wonder bread
//    		return "Wonder"; 
//    	}
//    }
}