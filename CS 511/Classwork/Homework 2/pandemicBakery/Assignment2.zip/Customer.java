package homework2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Customer implements Runnable {
    private Bakery bakery;
    private Random rnd;
    private List<BreadType> shoppingCart;
//    private int shopTime;
//    private int checkoutTime;
    private long shopTime; // Changing to long to properly record time in nanoseconds
    private long checkoutTime; // Changing to long to properly record time in nanoseconds

    /**
     * Initialize a customer object and randomize its shopping cart
     */
    public Customer(Bakery bakery) {
        // TODO
    	// Customer zin = new Customer(bakery, new Random(), new List<BreadType>, 0, 0);
    	this.bakery = bakery; // Set this.bakery equal to bakery
//    	System.out.println("Still initial but in customer threads on breads: Rye bread left=" + bakery.availableBread.get(BreadType.RYE) + ", Sourdough bread left=" + bakery.availableBread.get(BreadType.SOURDOUGH) + ", Wonder bread left=" + bakery.availableBread.get(BreadType.WONDER));
    	rnd = new Random(); // Initialize the new Random for the shopping cart
    	shoppingCart = new ArrayList<BreadType>(); // Initialize the shoppingCart List
    }

    /**
     * Run tasks for the customer
     */
    public void run() {
    	// TODO
    	
    	Customer zin = new Customer(bakery); // Initialize the customer
//    	System.out.println("Is available bread == null? answer= \"" + (bakery.availableBread == null) + "\"");
//    	System.out.println("Still initial but in customer threads on breads: Rye bread left=" + bakery.availableBread.get(BreadType.RYE) + ", Sourdough bread left=" + bakery.availableBread.get(BreadType.SOURDOUGH) + ", Wonder bread left=" + bakery.availableBread.get(BreadType.WONDER));
//        System.out.println("Breads when availableBread is public: Rye bread left=" + bakery.availableBread.get(BreadType.RYE) + ", Sourdough bread left=" + bakery.availableBread.get(BreadType.SOURDOUGH) + ", Wonder bread left=" + bakery.availableBread.get(BreadType.WONDER));
    	// Old from when we were creating a new customer
//    	System.out.println("Still initial but in customer threads on breads: Rye bread left=" + zin.bakery.availableBread.get(BreadType.RYE) + ", Sourdough bread left=" + zin.bakery.availableBread.get(BreadType.SOURDOUGH) + ", Wonder bread left=" + zin.bakery.availableBread.get(BreadType.WONDER));
    	
    	long shoppingStartTime = System.nanoTime(); // Start the amount of time it takes to shop
    	zin.fillShoppingCart(); // Fill the shopping cart
    	
//    	fillShoppingCart(); // Fill the shopping cart -- OLD from when we weren't creating a new customer
    	
    	long shoppingEndTime = System.nanoTime(); // End the amount of time it takes to shop in nanoseconds, since milliseconds always returned 0, since the operation was too fast
    	
//    	System.out.println(shoppingEndTime + "=endTime, " + shoppingStartTime + "=startTime," + (shoppingEndTime-shoppingStartTime) + "=end-start");
//    	zin.shopTime = (int) (shoppingEndTime - shoppingStartTime); // Set the shopping time equal to however long it takes to shop, old from when I used milliseconds
    	
    	zin.shopTime = shoppingEndTime - shoppingStartTime; // Set the shopping time equal to however long it takes to shop in nanoseconds, since milliseconds always returned 0, since the operation was too fast
    	
//    	shopTime = shoppingEndTime - shoppingStartTime; // Set the shopping time equal to however long it takes to shop in nanoseconds, since milliseconds always returned 0, since the operation was too fast -- OLD from when we weren't creating a new customer
    	
    	long checkoutStartTime = System.nanoTime(); // Start of checkout time in nanoseconds, since milliseconds always returned 0, since the operation was too fast
    	try {
    		zin.bakery.cashiers.acquire(); // Try to get a cashier and wait until one is free
    		System.out.println("Hash code \"" + hashCode() + "\" is checking out."); // Mention that this customer thread is checking out
//    		System.out.println("Cashiers available: " + cashiers.availablePermits()); // Debugging, used in confirming acquire/release function, which is working.
    	} catch (InterruptedException ie) {
    		ie.printStackTrace();
    	}
    	
    	zin.bakery.checkout(zin.getItemsValue()); // Checkout in the bakery
    	
    	zin.bakery.cashiers.release(); // Cashier is freed up
    	System.out.println("Hash code \"" + hashCode() + "\" is finished checking out.");
    	
//    	bakery.checkout(getItemsValue()); // Checkout in the bakery -- OLD from when we weren't creating a new customer
    	
    	long checkoutEndTime = System.nanoTime(); // End of checkout time in nanoseconds, since milliseconds always returned 0, since the operation was too fast
    	zin.checkoutTime = checkoutEndTime - checkoutStartTime; // Checkout time total in nanoseconds
    	
//    	checkoutTime = checkoutEndTime - checkoutStartTime; // Checkout time total in nanoseconds -- OLD from when we weren't creating a new customer
//    	System.out.println("Start time in nanosecs: " + start + ", End time in nanosecs: " + end + ", Difference in nanosecs: " + (end - start));
//    	System.out.println(zin.toString()); // Testing thread running
    	
    }

    /**
     * Return a string representation of the customer
     */
    public String toString() {
        return "Customer " + hashCode() + ": shoppingCart=" + Arrays.toString(shoppingCart.toArray()) + ", shopTime=" + shopTime + " ms, checkoutTime=" + checkoutTime + "ms";
    }

    /**
     * Add a bread item to the customer's shopping cart
     */
    private boolean addItem(BreadType bread) {
        // do not allow more than 3 items, addItem() does not call more than 3 times
        if (shoppingCart.size() >= 3) {
            return false;
        }
//        try {
////        	System.out.println("Hash code: " + hashCode() + ", availablePermits for shelf access = " + bakery.shelfAccess.availablePermits());
//			bakery.shelfAccess.acquire(); // Get access to the shelf
//			System.out.println("Hash code \"" + hashCode() + "\" is accessing the shelf.");
////			System.out.println("Hash code: " + hashCode() + ", availablePermits after acquire for shelf access = " + bakery.shelfAccess.availablePermits());
//        } catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//        System.out.println("Bread the hash \"" + hashCode() + "\" is looking for: " + bread);
//        System.out.println("Is available bread == null in addItem? answer= \"" + (bakery.availableBread == null) + "\"");
//        System.out.println("Breads when availableBread is public: Rye bread left=" + bakery.availableBread.get(BreadType.RYE) + ", Sourdough bread left=" + bakery.availableBread.get(BreadType.SOURDOUGH) + ", Wonder bread left=" + bakery.availableBread.get(BreadType.WONDER));
        try {
			bakery.shelfAccess.acquire(); // Restrict access to the shelf while grabbing bread by subtracting 1 from the shelfAccess semaphore (i.e. using acquire())
			System.out.println("Hash code \"" + hashCode() + "\" is accessing the shelf."); // Print message that we are accessing the shelf
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
        bakery.takeBread(bread); // Take a piece of bread from the shelf
        bakery.shelfAccess.release(); // Now that access to the shelf is no longer required, allow access to be taken again.
        shoppingCart.add(bread); // Add the taken bread to the shopping cart
        bakery.shelfAccess.release(); // Give access to the shelf back
        System.out.println("Hash code \"" + hashCode() + "\" grabbed a loaf of " + bread + " and has stopped accessing the shelf.");// + " The new sales total is " + sales);
        return true;
    }

    /**
     * Fill the customer's shopping cart with 1 to 3 random breads
     */
    private void fillShoppingCart() {
        int itemCnt = 1 + rnd.nextInt(3);
        while (itemCnt > 0) {
            addItem(BreadType.values()[rnd.nextInt(BreadType.values().length)]);
            itemCnt--;
        }
    }

    /**
     * Calculate the total value of the items in the customer's shopping cart
     */
    private float getItemsValue() {
        float value = 0;
        for (BreadType bread : shoppingCart) {
            value += bread.getPrice();
//            System.out.println(bread.getPrice() + " is the price of this loaf (debugging)");
        }
//        System.out.println("Value total is " + value); // For debugging
        return value;
    }
}